#ifndef SPI_DMA_H
#define SPI_DMA_H

#include "gd32e23x.h"

void gpio_config(void);
void spi_config(void);
void rcu_config(void);

#endif